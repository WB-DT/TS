require("dotenv").config();

const express = require("express");
const multer = require("multer");
const { AzureKeyCredential } = require("@azure/core-auth");
const DocumentIntelligence = require("@azure-rest/ai-document-intelligence").default;
const { createHash, randomBytes } = require("node:crypto");
const fs = require("node:fs/promises");
const {
  getLongRunningPoller,
  isUnexpected,
} = require("@azure-rest/ai-document-intelligence");
const path = require("node:path");
const auth = require("./auth");
const fieldCatalog = require("./fields");
const xref = require("./xref");
const ocr = require("./ocr");
const dataverseLogs = require("./dataverse-logs");
const lockedPrices = require("./locked-prices");
const database = require("./db");

const app = express();
const port = process.env.PORT || 3000;
const brandImageTypes = new Map([
  ["image/png", ".png"],
  ["image/jpeg", ".jpg"],
  ["image/webp", ".webp"],
]);
const brandUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024, files: 1 },
  fileFilter(_request, file, callback) {
    if (!brandImageTypes.has(file.mimetype)) {
      const error = new Error("Upload a PNG, JPEG, or WebP logo.");
      error.status = 400;
      callback(error);
      return;
    }
    callback(null, true);
  },
});
const requestFileTypes = new Map([
  ["application/pdf", ".pdf"],
  ["image/png", ".png"],
  ["image/jpeg", ".jpg"],
  ["image/tiff", ".tiff"],
  ["image/bmp", ".bmp"],
  ["image/webp", ".webp"],
  ["application/vnd.ms-excel", ".xls"],
  ["application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", ".xlsx"],
  ["application/msword", ".doc"],
  ["application/vnd.openxmlformats-officedocument.wordprocessingml.document", ".docx"],
]);
const requestUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024, files: 10 },
  fileFilter(_request, file, callback) {
    if (!requestFileTypes.has(file.mimetype)) {
      const error = new Error("Use PDF, image, Excel, or Word files.");
      error.status = 400;
      callback(error);
      return;
    }
    callback(null, true);
  },
});
const reportFileTypes = new Map([
  ["application/vnd.ms-excel", ".xls"],
  ["application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", ".xlsx"],
  ["text/csv", ".csv"],
  ["application/csv", ".csv"],
]);
const reportUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024, files: 1 },
  fileFilter(_request, file, callback) {
    if (!reportFileTypes.has(file.mimetype)) {
      const error = new Error("Upload an .xlsx or .csv report.");
      error.status = 400;
      callback(error);
      return;
    }
    callback(null, true);
  },
});

app.use(express.json({ limit: "2mb" }));
app.use(auth.sessionMiddleware);
auth.registerAuthRoutes(app);
require("./microsoft-auth").register(app, { database, safeUser: auth.safeUser, landingPath: auth.landingPath });
app.use(express.static(path.join(__dirname, "public"), { index: false }));

app.get("/login", auth.redirectIfAuthenticated, (_request, response) => {
  response.sendFile(path.join(__dirname, "views", "login.html"));
});

app.get("/", auth.redirectHome);

app.get("/api/branding", async (_request, response) => {
  const settings = await database.settings.get();
  response.set("Cache-Control", "no-store");
  response.json({
    companyName: settings.company_name || "QuoteFlow",
    logoPath: settings.logo_path || "/quoteflow-logo.svg",
    standardLeadTimeDays: Number(settings.standard_lead_time_days || 14),
  });
});

app.put("/api/branding", auth.requireRole("Manager"), async (request, response) => {
  const companyName = String(request.body?.companyName || "").trim();
  if (!companyName || companyName.length > 120) {
    response.status(400).json({ error: "Company name is required and must be 120 characters or fewer." });
    return;
  }
  const settings = await database.settings.update({ company_name: companyName });
  response.json({ companyName: settings.company_name, logoPath: settings.logo_path });
});

app.post("/api/branding/logo", auth.requireRole("Manager"), brandUpload.single("logo"), async (request, response) => {
  if (!request.file) {
    response.status(400).json({ error: "Choose a PNG, JPEG, or WebP logo." });
    return;
  }
  const extension = brandImageTypes.get(request.file.mimetype);
  const hash = createHash("sha256").update(request.file.buffer).digest("hex").slice(0, 20);
  const directory = path.join(__dirname, "public", "uploads", "brand");
  const filename = `logo-${hash}${extension}`;
  await fs.mkdir(directory, { recursive: true });
  await fs.writeFile(path.join(directory, filename), request.file.buffer);
  const logoPath = `/uploads/brand/${filename}`;
  await database.settings.update({ logo_path: logoPath });
  response.json({ logoPath });
});

app.get("/api/workspace", auth.requireAuth, async (request, response) => {
  const { user } = request;
  const [quotes, reports, settings] = await Promise.all([
    user.role === "Rep" ? database.quotes.listRequestsForRep(user) : database.quotes.listForWorkspace(user),
    user.role === "Manager"
      ? database.quotes.reportingData()
      : Promise.resolve({ cycleTimes: [], workload: [], reviserOutcomes: [], ocrAccuracy: [] }),
    database.settings.get(),
  ]);
  const quoters = user.role === "Manager" ? await database.users.listActiveQuoters() : [];
  const reassignments = user.role === "Manager" ? await database.quotes.listNeedsReassignment() : [];

  response.set("Cache-Control", "no-store");
  response.json({
    user,
    navigation: auth.navigationFor(user),
    quotes,
    reports,
    quoters,
    reassignments,
    branding: {
      companyName: settings.company_name || "QuoteFlow",
      logoPath: settings.logo_path || "/quoteflow-logo.svg",
      standardLeadTimeDays: Number(settings.standard_lead_time_days || 14),
    },
  });
});

// ---------- Locked prices (Margin Manager) ----------
const lockedPriceAccess = auth.requireRole("Margin Manager", "Manager");

// Reads the CSV and marks rows that are already saved. Shared by Preview and Import.
async function readLockedPriceFile(file) {
  const result = lockedPrices.parseLockedPrices(file.buffer, file.originalname);
  const accounts = [...new Set(result.records.map((record) => record.accountNumber).filter(Boolean))];
  const saved = new Set();
  for (let start = 0; start < accounts.length; start += 500) {
    const rows = await database.connection("locked_prices")
      .whereIn("account_number", accounts.slice(start, start + 500))
      .select("account_number", "item_number", "uom", "locked_in_date");
    for (const row of rows) {
      saved.add(lockedPrices.rowKey({ accountNumber: row.account_number, itemNumber: row.item_number, uom: row.uom, lockedInDate: row.locked_in_date }));
    }
  }
  const records = result.records.map((record) => ({
    ...record,
    alreadySaved: record.status === "Ready" && saved.has(lockedPrices.rowKey(record)),
  }));
  const ready = records.filter((record) => record.status === "Ready" && !record.alreadySaved);
  return {
    columnsMissing: result.columnsMissing,
    records,
    ready,
    summary: {
      total: records.length,
      ready: ready.length,
      alreadySaved: records.filter((record) => record.alreadySaved).length,
      needsAttention: records.filter((record) => record.status !== "Ready").length,
    },
  };
}

function lockedPriceFileError(error, response) {
  response.status(400).json({ error: error.status ? error.message : "That file could not be read. Make sure it is a .csv file." });
}

// Preview: shows what the CSV holds. Saves nothing.
app.post("/api/locked-prices/preview", lockedPriceAccess, reportUpload.single("file"), async (request, response) => {
  if (!request.file) {
    response.status(400).json({ error: "Choose a CSV file." });
    return;
  }
  let result;
  try {
    result = await readLockedPriceFile(request.file);
  } catch (error) {
    lockedPriceFileError(error, response);
    return;
  }
  response.json({
    columnsMissing: result.columnsMissing,
    summary: result.summary,
    // New and flagged rows only, capped so a big file stays fast.
    records: result.records.filter((record) => !record.alreadySaved).slice(0, 200),
  });
});

// Import: saves every Ready row that isn't saved yet. Flagged rows are skipped.
app.post("/api/locked-prices/import", lockedPriceAccess, reportUpload.single("file"), async (request, response) => {
  if (!request.file) {
    response.status(400).json({ error: "Choose a CSV file." });
    return;
  }
  let result;
  try {
    result = await readLockedPriceFile(request.file);
  } catch (error) {
    lockedPriceFileError(error, response);
    return;
  }
  const now = Math.floor(Date.now() / 1000);
  const rows = result.ready.map((record) => ({
    q_number: record.qNumber,
    account_number: record.accountNumber,
    company_name: record.companyName,
    ppl: record.ppl,
    item_number: record.itemNumber,
    item_description: record.itemDescription,
    uom: record.uom,
    sell_price: record.sellPrice,
    cost: record.cost,
    gp_percent: record.gpPercent,
    locked_in_date: record.lockedInDate,
    approved_by: record.approvedBy,
    source: "csv",
    source_file: String(request.file.originalname || "").slice(0, 255),
    imported_by_id: request.user.id,
    imported_at: now,
  }));
  await database.connection.transaction(async (trx) => {
    for (let start = 0; start < rows.length; start += 100) {
      await trx("locked_prices").insert(rows.slice(start, start + 100));
    }
  });
  response.json({ saved: rows.length, skipped: result.summary.total - rows.length });
});

// List: the saved prices, newest first, with optional filters.
app.get("/api/locked-prices", lockedPriceAccess, async (request, response) => {
  const search = String(request.query.search || "").trim();
  const from = String(request.query.from || "");
  const to = String(request.query.to || "");
  const settings = await database.settings.get();
  const floor = Number(settings.minimum_margin || 0.1);
  const query = database.connection("locked_prices");
  if (search) {
    const like = `%${search}%`;
    query.where((builder) => builder
      .where("account_number", "like", like)
      .orWhere("company_name", "like", like)
      .orWhere("item_number", "like", like)
      .orWhere("ppl", "like", like)
      .orWhere("q_number", "like", like));
  }
  if (/^\d{4}-\d{2}-\d{2}$/.test(from)) query.where("locked_in_date", ">=", from);
  if (/^\d{4}-\d{2}-\d{2}$/.test(to)) query.where("locked_in_date", "<=", to);
  if (request.query.belowFloor === "true") query.where("gp_percent", "<", floor);
  const rows = await query.clone().orderBy("locked_in_date", "desc").orderBy("account_number").limit(500);
  const [totals] = await query.clone().count({ count: "*" });
  const [all] = await database.connection("locked_prices")
    .count({ count: "*" })
    .countDistinct({ accounts: "account_number" });
  const [below] = await database.connection("locked_prices").where("gp_percent", "<", floor).count({ count: "*" });
  response.set("Cache-Control", "no-store");
  response.json({
    floor,
    totals: { prices: Number(all.count), accounts: Number(all.accounts), belowFloor: Number(below.count), matching: Number(totals.count) },
    rows,
  });
});

// ---------- Request log (copies of the Dataverse Quote Log and MDM Log) ----------
const requestLogAccess = auth.requireRole("Manager", "Qualifier");
const logUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 80 * 1024 * 1024, files: 1 } });

// Which rows count as each stage, written as database conditions (matches stageOf in dataverse-logs.js).
function applyStage(query, logKey, stage) {
  const returned = logKey === "quote" ? "cr714_datereturnedorkilled" : "cr714_datesentbacktorepmdm";
  const assigned = (builder) => {
    builder.whereNotNull("cr714_assignedto").orWhereNotNull("cr714_dateassigned");
    if (logKey === "mdm") builder.orWhereNotNull("cr714_quoter");
  };
  if (stage === "Returned or killed" || stage === "Sent back") query.whereNotNull(returned);
  if (stage === "Assigned") query.whereNull(returned).where(assigned);
  if (stage === "Qualified") query.whereNull(returned).whereNot(assigned).whereNotNull("cr714_datequalified");
  if (stage === "New") {
    query.whereNull(returned).whereNot(assigned);
    if (logKey === "quote") query.whereNull("cr714_datequalified");
  }
  return query;
}

// Import: adds new rows and updates rows that changed since the last import. Never deletes.
app.post("/api/request-log/import", requestLogAccess, logUpload.single("file"), async (request, response) => {
  if (!request.file) {
    response.status(400).json({ error: "Choose the .xlsx export." });
    return;
  }
  let results;
  try {
    results = dataverseLogs.parseDataverseExport(request.file.buffer);
  } catch (error) {
    response.status(400).json({ error: error.status ? error.message : "That file could not be read. Make sure it is the .xlsx export." });
    return;
  }
  const now = Math.floor(Date.now() / 1000);
  const summary = [];
  for (const result of results) {
    const log = dataverseLogs.LOGS[result.logKey];
    const existing = new Map(
      (await database.connection(log.table).select(log.idColumn, "qf_row_hash")).map((row) => [row[log.idColumn], row.qf_row_hash]),
    );
    const toInsert = [];
    const toUpdate = [];
    for (const record of result.records) {
      const savedHash = existing.get(record[log.idColumn]);
      if (savedHash === undefined) toInsert.push({ ...record, qf_imported_at: now });
      else if (savedHash !== record.qf_row_hash) toUpdate.push({ ...record, qf_imported_at: now });
    }
    await database.connection.transaction(async (trx) => {
      for (let start = 0; start < toInsert.length; start += 25) {
        await trx(log.table).insert(toInsert.slice(start, start + 25));
      }
      for (const record of toUpdate) {
        const { [log.idColumn]: id, ...changes } = record;
        await trx(log.table).where(log.idColumn, id).update(changes);
      }
    });
    summary.push({
      log: log.label,
      sheet: result.sheetName,
      added: toInsert.length,
      updated: toUpdate.length,
      unchanged: result.records.length - toInsert.length - toUpdate.length,
      skipped: result.skipped,
      missingColumns: result.missingColumns,
    });
  }
  response.json({ summary });
});

// List: one page of a log, newest first, with search and stage filters.
app.get("/api/request-log/:log", requestLogAccess, async (request, response) => {
  const logKey = request.params.log;
  const log = dataverseLogs.LOGS[logKey];
  if (!log) {
    response.status(404).json({ error: "Unknown log." });
    return;
  }
  const search = String(request.query.search || "").trim();
  const stage = String(request.query.stage || "");
  const page = Math.max(0, Number.parseInt(request.query.page, 10) || 0);
  const searchColumns = logKey === "quote"
    ? ["cr714_quotenumber", "cr714_companyname", "cr714_customernumber", "cr714_submittername", "cr714_assignedto", "cr714_ppl", "cr714_recordkey"]
    : ["cr714_accountnumber", "cr714_requestorname", "cr714_submittername", "cr714_branchwarehouse", "cr714_quoter", "cr714_assignedto", "cr714_ppl", "cr714_recordkey"];
  const listColumns = logKey === "quote"
    ? ["cr714_quotelogid", "createdon", "cr714_quotenumber", "cr714_companyname", "cr714_customernumber", "cr714_customerorlead", "cr714_requestpriority", "cr714_submittername", "cr714_category", "cr714_itemstoquote", "cr714_assignedto", "cr714_datequalified", "cr714_dateassigned", "cr714_datereturnedorkilled", "cr714_grossprofitpercent", "cr714_ppl"]
    : ["cr714_mdmlogid", "createdon", "cr714_accountnumber", "cr714_requestorname", "cr714_requestsource", "cr714_branchwarehouse", "cr714_bidduedate", "cr714_category", "cr714_itemstoquote", "cr714_quoter", "cr714_assignedto", "cr714_dateassigned", "cr714_datesentbacktorepmdm", "cr714_disposition", "cr714_ppl"];

  const base = () => {
    const query = database.connection(log.table);
    if (search) {
      const like = `%${search}%`;
      query.where((builder) => {
        for (const column of searchColumns) builder.orWhere(column, "like", like);
      });
    }
    return query;
  };
  const filtered = applyStage(base(), logKey, stage);
  const [matching] = await filtered.clone().count({ count: "*" });
  const rows = await filtered.clone().select(listColumns).orderBy("createdon", "desc").limit(100).offset(page * 100);
  const stageNames = logKey === "quote" ? ["New", "Qualified", "Assigned", "Returned or killed"] : ["New", "Assigned", "Sent back"];
  const stages = {};
  for (const name of stageNames) {
    const [result] = await applyStage(base(), logKey, name).count({ count: "*" });
    stages[name] = Number(result.count);
  }
  const [total] = await database.connection(log.table).count({ count: "*" });
  response.set("Cache-Control", "no-store");
  response.json({
    log: log.label,
    total: Number(total.count),
    matching: Number(matching.count),
    page,
    pageSize: 100,
    stages,
    rows: rows.map((row) => ({ ...row, stage: dataverseLogs.stageOf(logKey, row) })),
  });
});

// Detail: every column of one row, exactly as stored.
app.get("/api/request-log/:log/:id", requestLogAccess, async (request, response) => {
  const log = dataverseLogs.LOGS[request.params.log];
  if (!log) {
    response.status(404).json({ error: "Unknown log." });
    return;
  }
  const row = await database.connection(log.table).where(log.idColumn, request.params.id).first();
  if (!row) {
    response.status(404).json({ error: "Row not found." });
    return;
  }
  response.json({ log: log.label, row });
});

// ---------- Read a document (OCR proof) ----------
// Reads an uploaded PDF or photo in memory and returns the item lines it finds. Nothing is saved.
const ocrAccess = auth.requireRole("Manager", "Quoter");
const ocrUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 15 * 1024 * 1024, files: 1 } });

app.post("/api/ocr/read", ocrAccess, ocrUpload.single("file"), async (request, response) => {
  if (!request.file) {
    response.status(400).json({ error: "Choose a PDF or photo." });
    return;
  }
  try {
    const result = await ocr.readDocument({ buffer: request.file.buffer, fileName: request.file.originalname });
    response.set("Cache-Control", "no-store");
    response.json(result);
  } catch (error) {
    const status = Number(error.status) || 500;
    if (status >= 500) console.error("OCR failed:", error.message);
    response.status(status).json({
      error: status >= 500 ? "The document couldn't be read. Try a clearer photo or a different file." : error.message,
    });
  }
});

// ---------- Cross-reference (Margin Manager) ----------
// The same calculations as the Cross Reference Tool workbook, run on files uploaded one at a time.
const xrefAccess = auth.requireRole("Margin Manager", "Manager");
const xrefUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 40 * 1024 * 1024, files: 1 } });
const XREF_KINDS = ["items", "account", "house", "costing"];

async function loadXrefRun(id) {
  const run = await database.connection("xref_runs").where({ id }).first();
  if (!run) return null;
  const fileRows = await database.connection("xref_files").where({ run_id: id });
  const files = {};
  const fileInfo = {};
  for (const row of fileRows) {
    files[row.kind] = { headers: JSON.parse(row.headers_json || "[]"), rows: JSON.parse(row.rows_json || "[]") };
    fileInfo[row.kind] = { fileName: row.file_name, sheet: row.sheet_name, rows: row.row_count, uploadedAt: row.uploaded_at };
  }
  return { run, files, fileInfo, targets: JSON.parse(run.targets_json || "{}") };
}

function xrefResult(loaded) {
  const { run, files, fileInfo, targets } = loaded;
  const costColumn = run.cost_column === null ? xref.DEFAULT_COSTING_COST_COLUMN : run.cost_column;
  const result = xref.crossReference(files, { costColumn, targets });
  return {
    run: { id: run.id, name: run.name, createdBy: run.created_by_name, createdAt: run.created_at, updatedAt: run.updated_at },
    files: fileInfo,
    costColumn,
    costingHeaders: files.costing ? files.costing.headers : [],
    ...result,
  };
}

app.get("/api/xref/runs", xrefAccess, async (_request, response) => {
  const runs = await database.connection("xref_runs").orderBy("updated_at", "desc").limit(50)
    .select("id", "name", "created_by_name", "created_at", "updated_at");
  const files = await database.connection("xref_files").whereIn("run_id", runs.map((run) => run.id)).select("run_id", "kind");
  response.set("Cache-Control", "no-store");
  response.json({ runs: runs.map((run) => ({ ...run, kinds: files.filter((file) => file.run_id === run.id).map((file) => file.kind) })) });
});

app.post("/api/xref/runs", xrefAccess, async (request, response) => {
  const name = String(request.body?.name || "").trim().slice(0, 160);
  if (!name) {
    response.status(400).json({ error: "Give the run a name, such as the account number or Q-number." });
    return;
  }
  const now = Math.floor(Date.now() / 1000);
  const id = randomBytes(16).toString("hex");
  await database.connection("xref_runs").insert({
    id, name, cost_column: null, targets_json: "{}", created_by_id: request.user.id, created_by_name: request.user.name, created_at: now, updated_at: now,
  });
  response.status(201).json({ id });
});

app.get("/api/xref/runs/:id", xrefAccess, async (request, response) => {
  const loaded = await loadXrefRun(request.params.id);
  if (!loaded) {
    response.status(404).json({ error: "Run not found." });
    return;
  }
  response.set("Cache-Control", "no-store");
  response.json(xrefResult(loaded));
});

// Upload one file. Replacing the items list clears the target margins, since the lines changed.
app.post("/api/xref/runs/:id/files/:kind", xrefAccess, xrefUpload.single("file"), async (request, response) => {
  const { id, kind } = request.params;
  if (!XREF_KINDS.includes(kind)) {
    response.status(404).json({ error: "Unknown file type." });
    return;
  }
  if (!(await database.connection("xref_runs").where({ id }).first())) {
    response.status(404).json({ error: "Run not found." });
    return;
  }
  if (!request.file) {
    response.status(400).json({ error: "Choose an .xlsx or .csv file." });
    return;
  }
  let parsed;
  try {
    parsed = xref.readUpload(request.file.buffer, kind);
  } catch (error) {
    response.status(error.status || 400).json({ error: error.status ? error.message : "That file couldn't be read." });
    return;
  }
  const now = Math.floor(Date.now() / 1000);
  await database.connection.transaction(async (trx) => {
    await trx("xref_files").where({ run_id: id, kind }).delete();
    await trx("xref_files").insert({
      run_id: id, kind, file_name: request.file.originalname.slice(0, 255), sheet_name: String(parsed.sheet).slice(0, 120),
      row_count: parsed.rows.length, headers_json: JSON.stringify(parsed.headers), rows_json: JSON.stringify(parsed.rows),
      uploaded_by_id: request.user.id, uploaded_at: now,
    });
    const changes = { updated_at: now };
    if (kind === "items") changes.targets_json = "{}";
    await trx("xref_runs").where({ id }).update(changes);
  });
  const loaded = await loadXrefRun(id);
  response.json(xrefResult(loaded));
});

// Save the costing cost column and the target margins.
app.put("/api/xref/runs/:id", xrefAccess, async (request, response) => {
  const loaded = await loadXrefRun(request.params.id);
  if (!loaded) {
    response.status(404).json({ error: "Run not found." });
    return;
  }
  const changes = { updated_at: Math.floor(Date.now() / 1000) };
  if (typeof request.body?.costColumn === "string") changes.cost_column = request.body.costColumn.slice(0, 80);
  if (request.body?.targets && typeof request.body.targets === "object") {
    const targets = {};
    for (const [line, value] of Object.entries(request.body.targets)) {
      const number = Number(value);
      if (/^\d+$/.test(line) && Number.isFinite(number) && number > 0 && number < 1) targets[line] = number;
    }
    changes.targets_json = JSON.stringify(targets);
  }
  await database.connection("xref_runs").where({ id: request.params.id }).update(changes);
  response.json(xrefResult(await loadXrefRun(request.params.id)));
});

// Export the results in the same column order as the workbook's Usage or Consumption tab.
app.get("/api/xref/runs/:id/export", xrefAccess, async (request, response) => {
  const loaded = await loadXrefRun(request.params.id);
  if (!loaded) {
    response.status(404).json({ error: "Run not found." });
    return;
  }
  const result = xrefResult(loaded);
  const XLSX = require("xlsx");
  const rows = result.lines.map((l) => ({
    Order: l.line, Items: l.item, UMs: l.uom, Description: l.description, Category: l.category, Qty: l.qty,
    Price: l.price, "Extended Price": l.extendedPrice, "Financial Cost": l.financialCost, "Cost From": l.costSource,
    "Extended Cost": l.extendedCost, "Current Margin": l.currentMargin, "Target Margin": l.targetMargin,
    "Price at Target Margin": l.priceAtTarget, "Pricing Method": l.pricingMethod, Status: l.status,
    "Sub F/Inactive": l.substitute, Sustainable: l.sustainable, "Has Content": l.hasContent,
    "Catalog Price": l.catalogPrice, "Review Needed": l.reviewNeeded,
  }));
  const book = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(book, XLSX.utils.json_to_sheet(rows), "Cross reference");
  const buffer = XLSX.write(book, { type: "buffer", bookType: "xlsx" });
  const safeName = result.run.name.replace(/[^A-Za-z0-9 _-]/g, "").trim() || "cross-reference";
  response.set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  response.set("Content-Disposition", `attachment; filename="${safeName} - cross reference.xlsx"`);
  response.send(buffer);
});

// The quote workspace (5 stages), then version 2: people, workload, the bell,
// completed quotes, the final email and follow-ups. v2 must stay above the status routes.
const quoteStages = require("./quote-stages").register(app, { auth, database, multer, requestUpload, writeQuoteFile, uploadsRoot: __dirname });
const v2 = require("./v2").register(app, { auth, database, quoteStages });

app.get("/api/quoters", auth.requireRole("Manager"), async (_request, response) => {
  response.json(await database.users.listActiveQuoters());
});

app.get("/api/field-definitions", auth.requireRole("Quoter"), (request, response) => {
  const definitionSet = fieldCatalog.fieldsForTemplate(request.query.template);
  response.set("Cache-Control", "no-store");
  response.json({
    templates: fieldCatalog.templates,
    template: definitionSet.template,
    headerFields: definitionSet.headerFields,
    lineItemFields: definitionSet.lineItemFields,
    detailFields: definitionSet.detailFields,
  });
});

app.post("/api/reviews", auth.requireRole("Quoter"), async (request, response) => {
  const review = request.body;
  if (!review || typeof review !== "object" || !review.fields || !Array.isArray(review.lineItems)) {
    response.status(400).json({ error: "The quote review payload is incomplete." });
    return;
  }
  if (review.lineItems.length > 200) {
    response.status(413).json({ error: "A quote can contain no more than 200 line items." });
    return;
  }

  const submitted = await database.quotes.submitReview({ user: request.user, review });
  response.status(201).json(submitted);
});

app.get("/api/quotes/:id", auth.requireAuth, async (request, response) => {
  const detail = await database.quotes.getDetail(request.params.id);
  if (!detail) {
    response.status(404).json({ error: "Quote not found." });
    return;
  }
  const { user } = request;
  const isAssigned = detail.assigned_quoter_id === user.id;
  const isSubmitter = detail.submitted_by_rep === user.id || detail.submitted_by_id === user.id;
  if (user.role === "Quoter" && !isAssigned && !isSubmitter) {
    response.status(403).json({ error: "You do not have access to this quote." });
    return;
  }
  if (user.role === "Rep" && !isSubmitter) {
    response.status(403).json({ error: "You do not have access to this quote." });
    return;
  }
  response.set("Cache-Control", "no-store");
  // Reps never see cost, margin, or internal pricing columns.
  if (user.role === "Rep") {
    const sanitized = { ...detail };
    delete sanitized.contract_pricing;
    response.json(sanitized);
    return;
  }
  response.json(detail);
});

const quoteUploadDirectory = path.join(__dirname, "uploads", "quotes");

async function writeQuoteFile(uploaded, fileId) {
  const extension = requestFileTypes.get(uploaded.mimetype) || "";
  const baseName = String(uploaded.originalname || "document")
    .replace(/[<>:"/\\|?*\u0000-\u001f]/g, "_")
    .replace(/[. ]+$/g, "")
    .slice(0, 150) || "document";
  const fileName = path.extname(baseName) ? baseName : `${baseName}${extension}`;
  const storageFile = `${fileId}-${fileName}`;
  await fs.mkdir(quoteUploadDirectory, { recursive: true });
  const absolutePath = path.join(quoteUploadDirectory, storageFile);
  if (path.dirname(absolutePath) !== quoteUploadDirectory) {
    const error = new Error("Invalid file identifier.");
    error.status = 400;
    throw error;
  }
  await fs.writeFile(absolutePath, uploaded.buffer);
  return {
    fileName,
    fileType: uploaded.mimetype,
    fileHash: createHash("sha256").update(uploaded.buffer).digest("hex"),
    storageKey: `uploads/quotes/${storageFile}`,
    absolutePath,
  };
}

async function removeStoredFile(storageKey) {
  return; // Files are kept forever, so they can always be opened and checked.
  if (!storageKey) return;
  const absolutePath = path.join(__dirname, storageKey);
  if (!absolutePath.startsWith(path.join(__dirname, "uploads"))) return;
  await fs.rm(absolutePath, { force: true });
}

app.post("/api/quotes/:id/files", auth.requireAuth, requestUpload.single("file"), async (request, response) => {
  if (!request.file) {
    response.status(400).json({ error: "Choose a file to add." });
    return;
  }
  let stored = null;
  try {
    const detail = await database.quotes.getDetail(request.params.id);
    if (!detail) {
      response.status(404).json({ error: "Quote not found." });
      return;
    }
    const fileId = randomBytes(16).toString("hex");
    stored = await writeQuoteFile(request.file, fileId);
    const result = await database.quotes.addFile({
      quoteId: detail.id,
      user: request.user,
      file: { id: fileId, fileName: stored.fileName, fileType: stored.fileType, fileHash: stored.fileHash, storageKey: stored.storageKey },
    });
    response.status(201).json(result);
  } catch (error) {
    if (stored) await fs.rm(stored.absolutePath, { force: true });
    console.error(`File upload failed for quote ${request.params.id}:`, error);
    const status = Number(error.status) || 500;
    response.status(status).json({ error: status >= 500 ? "The file could not be uploaded. Please try again." : error.message });
  }
});

app.get("/api/quotes/:id/files/:fileId", auth.requireAuth, async (request, response) => {
  const detail = await database.quotes.getDetail(request.params.id);
  if (!detail) {
    response.status(404).json({ error: "Quote not found." });
    return;
  }
  const file = detail.files.find((entry) => entry.id === request.params.fileId);
  if (!file || !file.storageKey) {
    response.status(404).json({ error: "File not found." });
    return;
  }
  const absolutePath = path.join(__dirname, file.storageKey);
  if (!absolutePath.startsWith(path.join(__dirname, "uploads"))) {
    response.status(400).json({ error: "Invalid file location." });
    return;
  }
  response.set("Content-Type", file.fileType);
  response.set("Content-Disposition", `inline; filename="${String(file.fileName).replace(/"/g, "")}"`);
  response.sendFile(absolutePath);
});



app.get("/api/quotes/:id/comments", auth.requireAuth, async (request, response) => {
  const comments = await database.quotes.listComments(request.params.id, { forRep: request.user.role === "Rep" });
  response.set("Cache-Control", "no-store");
  response.json({ comments });
});

app.post("/api/quotes/:id/comments", auth.requireAuth, async (request, response) => {
  const body = String(request.body?.body || "").trim();
  if (!body) {
    response.status(400).json({ error: "Comment text is required." });
    return;
  }
  const comment = await database.quotes.addComment({
    quoteId: request.params.id,
    authorId: request.user.id,
    body,
    visibleToRep: request.user.role !== "Rep" && Boolean(request.body?.visibleToRep),
  });
  response.status(201).json(comment);
});

app.get("/api/notifications", auth.requireAuth, async (request, response) => {
  const notifications = await database.quotes.listNotifications(request.user.id);
  response.set("Cache-Control", "no-store");
  response.json({ notifications, unread: notifications.filter((item) => !item.read).length });
});

app.post("/api/notifications/:id/read", auth.requireAuth, async (request, response) => {
  response.json(await database.quotes.markNotificationRead(request.user.id, request.params.id));
});

app.get("/api/coaching", auth.requireAuth, async (request, response) => {
  const filter = request.user.role === "Manager" ? {} : { quoterId: request.user.id, visibility: "shared" };
  const notes = await database.quotes.listCoachingNotes(filter);
  response.set("Cache-Control", "no-store");
  response.json({ notes });
});

app.post("/api/quotes/:id/lines/:lineId/edit", auth.requireRole("Reviser", "Manager"), async (request, response) => {
  const detail = await database.quotes.getDetail(request.params.id);
  if (!detail) {
    response.status(404).json({ error: "Quote not found." });
    return;
  }
  try {
    const result = await database.quotes.reviserEditLine({
      quoteId: detail.id,
      lineItemId: request.params.lineId,
      user: request.user,
      changes: request.body?.changes || {},
      reason: request.body?.reason,
      reasonNote: request.body?.reasonNote,
      coaching: Boolean(request.body?.coaching),
      coachingCategory: request.body?.coachingCategory,
    });
    response.json(result);
  } catch (error) {
    response.status(Number(error.status) || 500).json({ error: error.message });
  }
});

app.post("/api/quotes/:id/coaching", auth.requireRole("Reviser", "Manager"), async (request, response) => {
  const detail = await database.quotes.getDetail(request.params.id);
  if (!detail) {
    response.status(404).json({ error: "Quote not found." });
    return;
  }
  const settings = await database.settings.get();
  const shareImmediately = String(settings.coaching_visibility || "manager") === "immediate";
  const note = await database.quotes.addCoachingNote({
    quoteId: detail.id,
    lineItemId: request.body?.lineItemId,
    quoterId: detail.assigned_quoter_id,
    reviserId: request.user.id,
    category: String(request.body?.category || "other"),
    note: request.body?.note,
    visibility: shareImmediately ? "shared" : "archived",
  });
  if (shareImmediately && detail.assigned_quoter_id) {
    await database.quotes.notify({ userId: detail.assigned_quoter_id, quoteId: detail.id, kind: "coaching", message: "A coaching note was shared with you." });
  }
  response.status(201).json(note);
});

app.post("/api/coaching/:id/share", auth.requireRole("Manager"), async (request, response) => {
  const note = await database.quotes.shareCoachingNote(request.params.id, request.user.id);
  if (note?.quoter_id) {
    await database.quotes.notify({ userId: note.quoter_id, quoteId: note.quote_id, kind: "coaching", message: "A coaching note was shared with you." });
  }
  response.json({ id: request.params.id, visibility: "shared" });
});

app.post("/api/coaching/:id/archive", auth.requireRole("Manager"), async (request, response) => {
  response.json(await database.quotes.archiveCoachingNote(request.params.id));
});

app.get("/api/templates", auth.requireAuth, async (request, response) => {
  const includeInactive = request.user.role === "Manager";
  response.set("Cache-Control", "no-store");
  response.json({ templates: await database.quotes.listTemplates({ includeInactive }) });
});

app.get("/api/templates/versions/:versionId", auth.requireAuth, async (request, response) => {
  const version = await database.quotes.getTemplateVersion(request.params.versionId);
  if (!version) {
    response.status(404).json({ error: "Template version not found." });
    return;
  }
  response.json(version);
});

app.post("/api/templates", auth.requireRole("Manager"), async (request, response) => {
  const { name, fileName, columns } = request.body || {};
  if (!name || !Array.isArray(columns) || !columns.length) {
    response.status(400).json({ error: "A template name and at least one column are required." });
    return;
  }
  response.status(201).json(await database.quotes.createTemplate({ name, createdById: request.user.id, fileName, columns }));
});

app.post("/api/templates/:id/versions", auth.requireRole("Manager"), async (request, response) => {
  const { fileName, columns } = request.body || {};
  if (!Array.isArray(columns) || !columns.length) {
    response.status(400).json({ error: "At least one column is required." });
    return;
  }
  response.status(201).json(await database.quotes.createTemplateVersion({ templateId: request.params.id, fileName, columns }));
});

app.post("/api/templates/:id/active", auth.requireRole("Manager"), async (request, response) => {
  response.json(await database.quotes.setTemplateActive(request.params.id, Boolean(request.body?.active)));
});

app.post("/api/templates/parse", auth.requireRole("Manager"), reportUpload.single("template"), async (request, response) => {
  if (!request.file) {
    response.status(400).json({ error: "Choose an Excel template file." });
    return;
  }
  try {
    const XLSX = require("xlsx");
    const workbook = XLSX.read(request.file.buffer, { type: "buffer", cellFormula: true });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const range = XLSX.utils.decode_range(sheet["!ref"]);
    const columns = [];
    for (let columnIndex = range.s.c; columnIndex <= range.e.c; columnIndex += 1) {
      const headerCell = sheet[XLSX.utils.encode_cell({ r: range.s.r, c: columnIndex })];
      const header = headerCell ? String(headerCell.v) : "";
      if (!header) continue;
      const formulaCell = sheet[XLSX.utils.encode_cell({ r: range.s.r + 1, c: columnIndex })];
      columns.push({
        header,
        excelColumn: XLSX.utils.encode_col(columnIndex),
        formula: formulaCell?.f ? `=${formulaCell.f}` : null,
      });
    }
    response.json({ fileName: request.file.originalname, columns });
  } catch (error) {
    response.status(422).json({ error: "Could not read that template file." });
  }
});

app.get("/api/settings", auth.requireAuth, async (request, response) => {
  const [workspace, personal] = await Promise.all([
    request.user.role === "Manager" ? database.settings.get() : Promise.resolve(null),
    database.quotes.getUserSettings(request.user.id),
  ]);
  response.set("Cache-Control", "no-store");
  response.json({ workspace, personal });
});

app.put("/api/settings", auth.requireRole("Manager"), async (request, response) => {
  const allowed = ["company_name", "standard_lead_time_days", "on_time_target_percent", "default_target_margin", "minimum_margin", "minimum_item_count", "cost_exempt_prefixes", "coaching_visibility", "decline_reasons", "return_reasons", "edit_reasons", "note_presets", "uom_presets"];
  const values = {};
  for (const key of allowed) {
    if (request.body?.[key] !== undefined) values[key] = request.body[key];
  }
  response.json(await database.settings.update(values));
});

app.put("/api/settings/personal", auth.requireAuth, async (request, response) => {
  const allowed = ["notifications_enabled", "default_view", "table_columns", "default_submitter_role", "default_template", "display_theme", "display_text_size"];
  const values = {};
  for (const key of allowed) {
    if (request.body?.[key] !== undefined) values[key] = request.body[key];
  }
  response.json(await database.quotes.updateUserSettings(request.user.id, values));
});

app.get("/api/users", auth.requireRole("Manager"), async (_request, response) => {
  response.set("Cache-Control", "no-store");
  response.json({
    users: await database.users.listAllWithRoles(),
    roles: database.users.allRoles,
    teams: database.users.teams,
    fieldHelp: fieldCatalog.fields.filter((field) => field.group === "users"),
  });
});

app.post("/api/users", auth.requireRole("Manager"), async (request, response) => {
  const user = await database.users.createUser(request.body, request.user);
  auth.registerDemoPassword(user.email);
  response.status(201).json(user);
});

app.get("/api/users/:id", auth.requireRole("Manager"), async (request, response) => {
  const user = await database.users.getDetail(request.params.id);
  if (!user) {
    response.status(404).json({ error: "User not found." });
    return;
  }
  response.set("Cache-Control", "no-store");
  response.json(user);
});

app.put("/api/users/:id/roles", auth.requireRole("Manager"), async (request, response) => {
  const user = await database.users.updateUserRoles({
    userId: request.params.id,
    roles: request.body?.roles,
    canApprove: request.body?.canApprove,
    changedBy: request.user,
  });
  response.json(user);
});

app.put("/api/users/:id/status", auth.requireRole("Manager"), async (request, response) => {
  const user = await database.users.setUserActive({
    userId: request.params.id,
    active: request.body?.active,
    changedBy: request.user,
  });
  response.json(user);
});

app.get("/api/search", auth.requireAuth, async (request, response) => {
  response.set("Cache-Control", "no-store");
  response.json(await database.quotes.globalSearch(request.query.q));
});

app.post("/api/quotes/:id/assign", auth.requireRole("Manager"), async (request, response) => {
  const quote = await database.quotes.assign({
    quoteId: request.params.id,
    quoterId: request.body?.quoterId,
    changedBy: request.user,
  });
  response.json({ id: quote.id, status: quote.status, assignedQuoterId: quote.assigned_quoter_id });
});

app.post("/api/quotes/:id/status", auth.requireAuth, async (request, response) => {
  const quote = await database.quotes.changeStatus({
    quoteId: request.params.id,
    nextStatus: request.body?.status,
    user: request.user,
    reason: request.body?.reason,
  });
  response.json({ id: quote.id, status: quote.status });
});

app.get("/:role/:page", auth.requirePageAccess, (_request, response) => {
  response.sendFile(path.join(__dirname, "views", "app.html"));
});

function fieldValue(field) {
  if (!field) return "";
  if (field.valueCurrency) {
    const currency = field.valueCurrency;
    return [currency.currencyCode, currency.amount].filter(Boolean).join(" ");
  }
  if (field.valueAddress) {
    return Object.values(field.valueAddress).filter(Boolean).join(", ");
  }
  for (const key of [
    "valueString",
    "valueDate",
    "valueTime",
    "valueNumber",
    "valueInteger",
    "valueBoolean",
  ]) {
    if (field[key] !== undefined && field[key] !== null) return String(field[key]);
  }
  return field.content || "";
}

function makeField(value, confidence = 0, options = {}) {
  const score = Number.isFinite(confidence) ? Math.min(1, Math.max(0, confidence)) : 0;
  return {
    value: value === null || value === undefined ? "" : String(value),
    confidence: score,
    needsReview: options.needsReview ?? score < 0.8,
  };
}

function findAzureField(fields, key) {
  const definition = fieldCatalog.fields.find((field) => field.key === key);
  for (const azureName of definition?.azureFields || []) {
    if (fields[azureName]) return fields[azureName];
  }
  return null;
}

function normalizeAzureField(fields, key) {
  const field = findAzureField(fields, key);
  return makeField(fieldValue(field), field?.confidence || 0);
}

function normalizeMatch(value) {
  return String(value || "").toLocaleLowerCase().replace(/[^a-z0-9]/g, "");
}

function parseAccountFromFilename(filename) {
  const leafName = String(filename || "").replace(/\\/g, "/").split("/").pop();
  const stem = leafName.replace(/\.(?:pdf|jpe?g|png|tiff?|bmp|heif)$/i, "").trim();
  const match = stem.match(/^(C\d+)[\s_-]+(.+)$/i);
  return match
    ? { number: match[1].toUpperCase(), name: match[2].trim() }
    : { number: "", name: "" };
}

function accountNameFromText(content) {
  const labeledLine = String(content || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .find((line) => /\b(?:customer(?:\s+name)?|account\s+name|bill\s+to|sold\s+to)\s*[:#-]\s*\S/i.test(line));
  const match = labeledLine?.match(/\b(?:customer(?:\s+name)?|account\s+name|bill\s+to|sold\s+to)\s*[:#-]\s*(.+)$/i);
  return match?.[1]?.trim() || "";
}

function accountDetailsFromDocument(content, fields, filenameAccount) {
  const azureNumber = fields.CustomerId || fields.CustomerNumber || fields.AccountNumber;
  const azureNumberValue = fieldValue(azureNumber);
  const textNumber = content.match(/\bC\d+\b/i)?.[0] || "";
  const documentNumber = azureNumberValue || textNumber;
  const azureName = fields.CustomerName;
  const azureNameValue = fieldValue(azureName);
  const normalizedContent = normalizeMatch(content);
  const filenameNameMatched = filenameAccount.name
    && normalizedContent.includes(normalizeMatch(filenameAccount.name));
  const labeledName = accountNameFromText(content);
  const documentName = filenameNameMatched
    ? filenameAccount.name
    : azureNameValue || labeledName;

  return {
    number: documentNumber,
    numberConfidence: azureNumberValue ? azureNumber.confidence || 0 : textNumber ? 0.82 : 0,
    name: documentName,
    nameConfidence: filenameNameMatched ? 0.92 : azureName?.confidence || (labeledName ? 0.78 : 0),
  };
}

function countPerUnit(unitOfMeasure, description) {
  const text = `${unitOfMeasure} ${description}`.toLocaleLowerCase();
  if (/\bgross\b/.test(text)) return { value: 144, confidence: 0.96 };
  if (/\bdozen\b|\bdoz\b/.test(text)) return { value: 12, confidence: 0.96 };
  if (/\bpair\b|\bpr\b/.test(text)) return { value: 2, confidence: 0.94 };
  const count = text.match(/\b(\d+(?:\.\d+)?)\s*(?:\/\s*)?(?:count|ct|pack|pk|piece|pc|unit)s?\b/i);
  if (count) return { value: Number(count[1]), confidence: 0.9 };
  if (/\beach\b|\beaches\b|\bunit\b/.test(text)) return { value: 1, confidence: 0.94 };
  return { value: 1, confidence: unitOfMeasure ? 0.58 : 0.45 };
}

function numericValue(field) {
  if (typeof field?.valueCurrency?.amount === "number") return field.valueCurrency.amount;
  for (const key of ["valueNumber", "valueInteger"]) {
    if (typeof field?.[key] === "number") return field[key];
  }
  const parsed = Number(fieldValue(field).replace(/[^\d.-]/g, ""));
  return Number.isFinite(parsed) ? parsed : null;
}

function currencyCode(field) {
  return field?.valueCurrency?.currencyCode || "";
}

function sourcePageLine(item, pages) {
  const region = item.boundingRegions?.[0];
  const pageNumber = region?.pageNumber;
  if (!pageNumber) return makeField("", 0);
  const page = pages.find((candidate) => candidate.pageNumber === pageNumber);
  const lines = page?.lines || [];
  const polygon = region.polygon || region.boundingPolygon || [];
  const itemY = polygon.length ? polygon.filter((_value, index) => index % 2 === 1).reduce((sum, y) => sum + y, 0) / (polygon.length / 2) : null;
  let closestLine = -1;
  let closestDistance = Infinity;

  lines.forEach((line, index) => {
    const linePolygon = line.polygon || line.boundingPolygon || [];
    if (itemY === null || !linePolygon.length) return;
    const lineY = linePolygon.filter((_value, coordinateIndex) => coordinateIndex % 2 === 1).reduce((sum, y) => sum + y, 0) / (linePolygon.length / 2);
    const distance = Math.abs(lineY - itemY);
    if (distance < closestDistance) {
      closestDistance = distance;
      closestLine = index + 1;
    }
  });

  return makeField(closestLine > 0 ? `Page ${pageNumber}, line ${closestLine}` : `Page ${pageNumber}`, closestLine > 0 ? 0.75 : 0.65);
}

function summarizeDescription(description) {
  const summary = String(description || "")
    .replace(/^\s*(?:[A-Z0-9][A-Z0-9._/-]{2,}\s+){1,2}(?=[A-Za-z])/, "")
    .split(/[;|\n]/)[0]
    .replace(/\s+/g, " ")
    .trim();
  return summary.length > 100 ? `${summary.slice(0, 97).trimEnd()}...` : summary;
}

function normalizeLineItem(item, pages) {
  const itemFields = item.valueObject || {};
  const values = {};
  for (const definition of fieldCatalog.fields.filter((field) => field.group === "line")) {
    const azureField = findAzureField(itemFields, definition.key);
    values[definition.key] = makeField(fieldValue(azureField), azureField?.confidence || 0);
  }

  const description = values.description.value;
  const summary = summarizeDescription(description);
  values.descriptionSummary = makeField(summary, summary ? 0.65 : 0, { needsReview: Boolean(summary) });

  const count = countPerUnit(values.unitOfMeasure.value, description);
  values.countPerUnit = makeField(count.value, count.confidence);

  const unitPriceField = findAzureField(itemFields, "pricePerUnitOfMeasure");
  const unitPrice = numericValue(unitPriceField);
  const normalizedPrice = unitPrice !== null && count.value > 0
    ? `${currencyCode(unitPriceField)}${currencyCode(unitPriceField) ? " " : ""}${(unitPrice / count.value).toFixed(2)}`
    : "";
  values.normalizedUnitPrice = makeField(normalizedPrice, normalizedPrice ? Math.min(unitPriceField?.confidence || 0, count.confidence) : 0);
  values.sourcePageLine = sourcePageLine(item, pages);
  return values;
}

function normalizeInvoice(document, request) {
  const documentFields = document?.fields || {};
  const items = documentFields.Items?.valueArray || [];
  const content = request.analyzeContent || "";
  const filenameAccount = parseAccountFromFilename(request.file.originalname);
  const documentAccount = accountDetailsFromDocument(content, documentFields, filenameAccount);
  const accountNumber = filenameAccount.number || documentAccount.number;
  const accountName = filenameAccount.name || documentAccount.name;
  const mismatches = [];

  if (filenameAccount.number && documentAccount.number && filenameAccount.number !== documentAccount.number.trim().toUpperCase()) {
    mismatches.push(`Filename account number ${filenameAccount.number} differs from document account number ${documentAccount.number}.`);
  }
  if (filenameAccount.name && documentAccount.name && normalizeMatch(filenameAccount.name) !== normalizeMatch(documentAccount.name)) {
    mismatches.push(`Filename account name ${filenameAccount.name} differs from document account name ${documentAccount.name}.`);
  }

  const canCompareAccount = Boolean(
    (filenameAccount.number || filenameAccount.name)
    && (documentAccount.number || documentAccount.name),
  );

  const source = normalizeAzureField(documentFields, "invoiceSource");
  const date = normalizeAzureField(documentFields, "invoiceDate");
  const description = content;
  const hasContractWords = /\bcontract(?:ual)?\b/i.test(description);
  const fields = {
    quoteId: makeField(`Q-${new Date().getFullYear()}-${randomBytes(3).toString("hex").toUpperCase()}`, 1),
    accountNumber: makeField(accountNumber, filenameAccount.number ? 0.98 : documentAccount.numberConfidence, { needsReview: !accountNumber || mismatches.some((item) => item.includes("number")) }),
    accountName: makeField(accountName, filenameAccount.name ? 0.98 : documentAccount.nameConfidence, { needsReview: !accountName || mismatches.some((item) => item.includes("name")) }),
    invoiceSource: source,
    invoiceDate: makeField(date.value, date.value ? date.confidence : 0),
    uploadDate: makeField(new Date().toISOString().slice(0, 10), 1),
    uploadedBy: makeField(request.user.name, 1),
    contractPricing: makeField(hasContractWords ? "Yes" : "No", hasContractWords ? 0.94 : 0.68),
    itemLineCount: makeField(items.length, 0.98),
    duplicateWarning: makeField("Checking for duplicates...", 1, { needsReview: false }),
    accountMismatch: makeField(
      mismatches.join(" ") || (canCompareAccount ? "No mismatch detected." : "Could not compare: account details were not found in both filename and document."),
      mismatches.length || !canCompareAccount ? 0.65 : 1,
      { needsReview: Boolean(mismatches.length || !canCompareAccount) },
    ),
  };

  const details = {};
  for (const definition of fieldCatalog.fields.filter((field) => field.group === "detail")) {
    details[definition.key] = normalizeAzureField(documentFields, definition.key);
  }

  return {
    template: request.template,
    filename: request.file.originalname,
    fields,
    details,
    lineItems: items.map((item) => normalizeLineItem(item, request.pages || [])),
  };
}

async function analyzeBuffer({ buffer, mimetype, originalname, user, template }) {
  const endpoint = process.env.AZURE_DI_ENDPOINT;
  const key = process.env.AZURE_DI_KEY;
  if (!endpoint || !key) {
    const error = new Error("Azure Document Intelligence is not configured. Set AZURE_DI_ENDPOINT and AZURE_DI_KEY in .env.");
    error.status = 503;
    throw error;
  }

  const client = DocumentIntelligence(endpoint, new AzureKeyCredential(key), { apiVersion: "2024-11-30" });
  const initialResponse = await client
    .path("/documentModels/{modelId}:analyze", "prebuilt-invoice")
    .post({ contentType: mimetype, body: buffer });

  if (isUnexpected(initialResponse)) {
    throw new Error(initialResponse.body?.error?.message || "Azure could not analyze this document.");
  }

  const poller = getLongRunningPoller(client, initialResponse);
  const result = await poller.pollUntilDone();
  if (isUnexpected(result)) {
    throw new Error(result.body?.error?.message || "Document analysis failed.");
  }

  const analyzeResult = result.body.analyzeResult;
  const documents = analyzeResult?.documents || [];
  if (!documents.length) {
    const error = new Error("No invoice fields were found. Try a clearer invoice or quote.");
    error.status = 422;
    throw error;
  }

  return normalizeInvoice(documents[0], {
    file: { originalname, buffer, mimetype },
    user,
    template,
    analyzeContent: analyzeResult.content,
    pages: analyzeResult.pages || [],
  });
}

app.use((error, _request, response, _next) => {
  if (error instanceof multer.MulterError && ["LIMIT_FILE_SIZE", "LIMIT_FILE_COUNT"].includes(error.code)) {
    console.error("File upload rejected:", error.message);
    response.status(413).json({ error: error.code === "LIMIT_FILE_COUNT" ? "Attach no more than 10 files." : "Files must be 20 MB or smaller." });
    return;
  }
  const status = Number(error.status) || 500;
  if (status >= 500) console.error("Request failed:", error.message);
  response.status(status).json({
    error: status >= 500 ? "The request could not be completed." : error.message,
  });
});

database.initialize()
  // Version 2 defaults (job titles, tags, departments, settings). A problem here is logged, not fatal.
  .then(() => v2.ready().catch((error) => console.error("Version 2 setup:", error.message)))
  .then(() => {
    app.listen(port, () => {
      console.log(`QuoteFlow listening on http://localhost:${port}`);
    });
  })
  .catch((error) => {
    console.error("Database initialization failed:", error.message);
    process.exit(1);
  });